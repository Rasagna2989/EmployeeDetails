package com.employee.model;
public enum Gender {
   male,
   female,
   others,
   donotspecify
}